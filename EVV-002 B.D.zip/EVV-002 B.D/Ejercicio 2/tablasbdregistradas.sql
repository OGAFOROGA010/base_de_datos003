--mostrar en pantalla los datos registrados en la tabla clientes
SELECT * FROM restaurante.clientes
SELECT * FROM restaurante.categorias
SELECT * FROM restaurante.motos
SELECT * FROM restaurante.domiciliarios
SELECT * FROM restaurante.platos
SELECT * FROM restaurante.pedidos
SELECT * FROM restaurante.solicitudes