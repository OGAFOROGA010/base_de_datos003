--ingresamos datos a la tabla clientes
INSERT INTO
restaurante.clientes (Id_cedula,Nombre,Celular,Direccion,Barrio)
VALUES
(10213344, 'Angelica Ceron', 3124567890, 'Cra 10 2-09' 'La Paz'),
(129831312, 'Yoimar Diaz', 3234587654, 'Calle 6 Cra 20 3-23', 'La Gabarra'),
(146754882, 'Alejandro Solis', 3124569843,'Cra 7A 28  4-65', 'Pamplona'),
(23245535, 'David Perez', 3145980343,'Cra 10  8-24', 'El Recuerdo'),
(1061743728,'Valentina Chaparro', 3175695467 ,'Cra 15  5-17', 'San Jose');

INSERT INTO
restaurante.categorias (Id_categoria, Precio_actual,Entradas,Plato_fuerte,Bebidas)
VALUES
(1,25500,'Empanadas de carne','Bandeja paisa','Gaseosa personal'),
(2,28000, 'Patacones con hogao','Arroz con pollo','Agua mineral'),
(3,26000,'Arepas de queso','Pechuga a la plancha,'Limonada natural'),
(4,25000,'Deditos de queso','Carne asada','Jugo de mango'),
(5,29000,'Chorizo con limon','Mojarra fria','Jugo de mora');

INSERT INTO 
VALUES
restaurante.motos (Id_placa,Vencimiento,Modelo,Soat)
(56123, '15/03/2027', 2020, 'Vigente'),
(34534, '20/08/2026', 2018, 'Vencido'),
(80566, '10/01/2027', 2022, 'Vigente'),
(45780, '05/06/2027', 2026, 'Vigente'),
(34234, '22/11/2027', 2023, 'Vigente');

INSERT INTO
restaurante.domiciliarios (Id_domiciliario,Nombre,Id_placa)
VALUES
(35,'Esteban Plazas',56123),
(36,'Andres Casas', 34534),
(37,'Angela Palacios', 80566),
(38, 'Ronal Rojas', 45780),
(39, 'Daniela Fernandez', 34234);


INSERT INTO
restaurante.platos (Id_plato,Nombre,Precio_actual,Id_categoria)
VALUES
(23, 'Bandeja paisa', 25500, 1),
(24, 'Arroz con pollo', 28000, 2),
(25, 'Pechuga a la plancha', 26000, 3),
(26, 'Carne asada', 25000, 4),
(27, 'Mojarra fria', 29000, 5);

INSERT INTO
restaurante.pedidos (Id_pedido, Id_plato, Id_domiciliario, Id_cedula, Cantidad, Precio_unitario)
VALUES
(1, 23, 35, 10213344, 2, 25500),
(2, 24, 36, 129831312, 1, 28000),
(3, 25, 37, 146754882, 1, 26000),
(4, 26, 38, 23245535, 1, 25000),
(5, 27, 39, 1061743728, 1, 29000);

INSERT INTO
restaurante.solicitudes (Id_solicitud, Id_plato, Id_pedido)
VALUES
(1,23,1),
(2,24,2),
(3,25,3),
(4,26,4),
(5,27,5);



