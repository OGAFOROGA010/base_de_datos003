SELECT * FROM torneo.fichas
SELECT * FROM torneo.equipos
SELECT * FROM torneo.jugadores
SELECT * FROM torneo.canchas
SELECT * FROM torneo.arbitros
SELECT * FROM torneo.partidos
SELECT * FROM torneo.participaciones
SELECT * FROM torneo.partido_arbitro