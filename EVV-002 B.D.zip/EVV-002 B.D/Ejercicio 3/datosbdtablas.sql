INSERT INTO 
torneo.fichas (Id_ficha,Programa,Jornada)
VALUES
('3411090', 'ADSO', 'Diurna'),
('3411091', 'ADSO', 'Nocturna'),
('3465749', 'ADSO', 'Diurna'),
('3564789', 'Gestion financiera', 'Nocturna'),
('3745739', 'ADSO', 'Diurna');

INSERT INTO 
torneo.equipos (Id_equipo, Nombre, Color_camiseta, Id_ficha)
VALUES
(1,'Los Tigres', 'Azul', '3411090'),
(2,'Los Leones', 'Rojo', '3411091'),
(3,'Los angeles', 'Amarillo', '3465749'),
(4,'Las rocas', 'Blanco','3564789'),
(5,'Las Focas','Verde','3745739');

INSERT INTO 
torneo.jugadores (Id_jugador,Documento,Nombre,Fecha_nacimiento,Numero_camisenta,Id_equipo)
VALUES
('1001',1247482937,  'Carlos Perez', '2005-03-12', 10, 1),
('1002', 1673484828,'Juan Lopez', '2004-06-20', 7, 2),
('1003', 237484838, 'Andres Ruiz', '2005-09-15', 9, 3),
('1004',1838384223 , 'David Torres', '2004-12-10', 5, 4),
('1005',12747478383, 'Jose Luis Ordoñez','2003-11-10',9,5);


UPDATE torneo.equipos
SET Capitan_documento = 1247482937
WHERE Id_equipo = 1;

UPDATE torneo.equipos
SET Capitan_documento =1673484828
WHERE Id_equipo = 2;

UPDATE torneo.equipos
SET Capitan_documento =  237484838
WHERE Id_equipo = 3;

UPDATE torneo.equipos
SET Capitan_documento = 1838384223 
WHERE Id_equipo = 4;

UPDATE torneo.equipos
SET Capitan_documento = 12747478383
WHERE Id_equipo = 5;


INSERT INTO 
torneo.canchas (Id_cancha,Nombre,Ubicacion,Capacidad)
VALUES
(1, 'Cancha Principal', 'Bloque deportivo', 30),
(2, 'Cancha Auxiliar', 'Zona recreativa', 20),
(3, 'Cancha Auxiliar', 'Zona recreativa', 20),
(4, 'Cancha Principal', 'Bloque deportivo', 20),
(5, 'Cancha Auxiliar', 'Zona recreativa', 20);


INSERT INTO 
torneo.arbitros (Id_arbitro,Documento,Nombre,Celular)
VALUES
(2001, 12432534,'Pedro Gomez', '3001234567'),
(2002, 1061744456,'Luis Martinez', '3101234567'),
(2003, 135468890,'Fabian Gonzales', '300543297'),
(2004, 124455666,'Pedro Gomez', '3145678900'),
(2005, 133453656,'Pedro Gomez', '3215695373');


INSERT INTO
torneo.partidos (Id_partido, Fecha, Hora, Fase, Goles_local, Goles_visitante,Id_cancha, Equipo_local, Equipo_visitante)
VALUES
(1,'2026-11-20', '09:00', 'grupos', 2, 1, 1, 1, 2),
(2,'2026-11-22', '10:00', 'grupos', 6, 0, 2, 2, 1),
(3,'2026-11-10', '11:00', 'grupos', 1, 2, 1, 1, 2),
(4,'2026-10-8', '10:00', 'grupos', 3, 3, 1, 1, 2),
(5,'2026-10-2', '09:00', 'grupos', 4, 5, 1, 1, 2);


INSERT INTO 
torneo.participaciones (Id_partido,Id_jugador,Goles,Tarjetas_amarillas,Tarjeta_roja,Minutos_jugados)
VALUES
(1, '1001', 1, 0, 0, 40),
(1, '1002', 1, 1, 0, 35),
(1, '1003', 1, 0, 0, 40),
(1, '1004', 0, 0, 0, 30),
(2, '1004', 1, 0, 1, 30);


INSERT INTO 
torneo.partido_arbitro (Id_partido,Id_arbitro,rol)
VALUES
(1, '2001', 'central'),
(1, '2002', 'asistente'),
(2, '2003', 'anotador'),
(2, '2004', 'asistente'),
(2, '2005', 'anotador');

