--crear el esquema para nuestra base de datos
CREATE SCHEMA IF NOT EXISTS restaurante;

--creamos las tablas para las entidades independientes
CREATE TABLE IF NOT EXISTS restaurante.clientes (
Id_cedula INT UNIQUE NOT NULL primary key, 
Nombre VARCHAR (50) NOT NULL, 
Celular VARCHAR (10) NOT NULL, 
Direccion VARCHAR (50) NOT NULL, 
Barrio VARCHAR (50) NOT NULL 
);

--Segunda tabla independiente
CREATE TABLE IF NOT EXISTS restaurante.categorias (
Id_categoria INT UNIQUE NOT NULL primary key,
precio_actual DECIMAL (10,0) NOT NULL,
Entradas VARCHAR (50) NOT NULL, 
Platos_fuerte VARCHAR (80) NOT NULL,
Bebidas VARCHAR (30) NOT NULL
);

--creamos las tablas para las entidades independientes
CREATE TABLE IF NOT EXISTS restaurante.motos (
Id_placa INT UNIQUE NOT NULL PRIMARY KEY,
Vencimiento VARCHAR (20) NOT NULL,
Modelo VARCHAR (20) NOT NULL,
SOAT VARCHAR (50) NOT NULL
);

CREATE TABLE IF NOT EXISTS restaurante.domiciliarios(
Id_domiciliario INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR (100) NOT NULL,
Id_placa INT NOT NULL,
CONSTRAINT fk_placa FOREIGN KEY (Id_placa) REFERENCES restaurante.motos (Id_placa)
);

 CREATE TABLE IF NOT EXISTS restaurante.platos (
Id_plato INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR (50) NOT NULL,
precio_actual DECIMAL (10,0) NOT NULL,
Id_categoria INT NOT NULL,
CONSTRAINT fk_categoria FOREIGN KEY (Id_categoria) REFERENCES restaurante.categorias (Id_categoria)
);

CREATE TABLE IF NOT EXISTS restaurante.pedidos (
Id_pedido INT UNIQUE NOT NULL PRIMARY KEY,
Id_plato INT NOT NULL,
Id_domiciliario INT NOT NULL,
Id_cedula INT NOT NULL,
Cantidad INT NOT NULL,
Precio_unitario DECIMAL (10,0) NOT NULL,
CONSTRAINT fk_plato FOREIGN KEY (Id_plato) REFERENCES restaurante.platos (Id_plato),
CONSTRAINT fk_domiciliario FOREIGN KEY (Id_domiciliario) REFERENCES restaurante.domiciliarios (Id_domiciliario),
CONSTRAINT fk_cedula FOREIGN KEY (Id_cedula) REFERENCES restaurante.clientes (Id_cedula)
);

CREATE TABLE IF NOT EXISTS restaurante.solicitudes (
Id_solicitud INT UNIQUE NOT NULL PRIMARY KEY,
Id_plato INT NOT NULL,
Id_pedido INT NOT NULL,
CONSTRAINT fk_plato FOREIGN KEY (Id_plato) REFERENCES restaurante.platos (Id_plato)
)








