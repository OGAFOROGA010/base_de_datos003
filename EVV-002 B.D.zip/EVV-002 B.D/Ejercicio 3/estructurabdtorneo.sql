CREATE SCHEMA IF NOT EXISTS torneo;

CREATE TABLE IF NOT EXISTS torneo.fichas (
Id_ficha INT UNIQUE NOT NULL PRIMARY KEY,
Programa VARCHAR (100) NOT NULL,
Jornada VARCHAR (30) NOT NULL
);

CREATE TABLE IF NOT EXISTS torneo.arbitros (
Id_arbitro INT UNIQUE NOT NULL PRIMARY KEY,
Documento VARCHAR (20) NOT NULL,
Nombre VARCHAR (50) NOT NULL,
Celular VARCHAR (10) NOT NULL
);

CREATE TABLE IF NOT EXISTS torneo.canchas (
Id_cancha INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR (80) NOT NULL,
Ubicacion VARCHAR (100) NOT NULL,
Capacidad INT NOT NULL
);

CREATE TABLE IF NOT EXISTS torneo.equipos (
Id_equipo INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR (50) NOT NULL,
Color_camiseta VARCHAR (20) NOT NULL,
Id_ficha INT UNIQUE NOT NULL,
Capitan_documento VARCHAR (20) UNIQUE NOT NULL,
CONSTRAINT fk_ficha FOREIGN KEY (Id_ficha) REFERENCES torneo.fichas (Id_ficha)
);

CREATE TABLE IF NOT EXISTS torneo.jugadores (
Id_jugador INT NOT NULL PRIMARY KEY,
Documento VARCHAR (20) NOT NULL,
Nombre VARCHAR (50) NOT NULL,
Fecha_nacimiento DATE NOT NULL,
Numero_camiseta INT NOT NULL,
Id_equipo INT NOT NULL,
CONSTRAINT fk_equipo FOREIGN KEY (Id_equipo) REFERENCES torneo.equipos (Id_equipo),
UNIQUE (Id_equipo, Id_jugador)
);
ALTER TABLE torneo.jugadores
ADD CONSTRAINT uq_jugador_equipo
UNIQUE (Id_equipo, documento);

ALTER TABLE torneo.equipos
ADD CONSTRAINT fk_capitan
FOREIGN KEY (Id_equipo, Capitan_documento)
REFERENCES torneo.jugadores(Id_equipo, documento);

CREATE TABLE IF NOT EXISTS torneo.partido_arbitro (
Id_partido INT NOT NULL,
Id_arbitro INT NOT NULL,
Rol VARCHAR (20) NOT NULL,
PRIMARY KEY (Id_partido, Id_arbitro),
CONSTRAINT fk_partido FOREIGN KEY (Id_partido) REFERENCES torneo.partidos (Id_partido),
CONSTRAINT fk_arbitro FOREIGN KEY (Id_arbitro) REFERENCES torneo.arbitros (Id_arbitro),

CHECK (rol IN ('central', 'asistente', 'anotador'))
);

CREATE TABLE IF NOT EXISTS torneo.participaciones (
Id_partido INT NOT NULL,
Id_jugador INT NOT NULL,
Goles INT NOT NULL,
Tarjetas_amarillas INT NOT NULL,
Tarjeta_roja INT NOT NULL,
Minutos_jugados INT NOT NULL,
PRIMARY KEY (Id_partido, Id_jugador),
CONSTRAINT fk_partido FOREIGN KEY (Id_partido) REFERENCES torneo.partidos (Id_partido),
CONSTRAINT fk_jugador FOREIGN KEY (Id_jugador) REFERENCES torneo.jugadores (Id_jugador),
CHECK (Goles >=0),
CHECK (Tarjetas_amarillas >=0),
CHECK (Tarjeta_roja >=0),
CHECK (Minutos_jugados >=0)
);

CREATE TABLE IF NOT EXISTS torneo.partidos (
Id_partido INT UNIQUE NOT NULL PRIMARY KEY,
Fecha DATE NOT NULL,
Hora TIME NOT NULL,
Fase VARCHAR (20) NOT NULL,
Goles_local INT  NOT NULL,
Goles_visitante INT  NOT NULL,
Id_cancha INT NOT NULL,
Equipo_local INT  NOT NULL,
Equipo_visitante INT  NOT NULL,
CONSTRAINT Id_cancha FOREIGN KEY (Id_cancha) REFERENCES torneo.canchas (Id_cancha),
CONSTRAINT Equipo_local FOREIGN KEY (Equipo_local) REFERENCES torneo.partidos (Equipo_local),
CONSTRAINT Equipo_visitante FOREIGN KEY (Equipo_visitante) REFERENCES torneo.partidos (Equipo_local),
CHECK (Equipo_local <> Equipo_visitante),
CHECK (Fase IN ('grupos', 'cuartos', 'semifinal', 'final')),
CHECK (Goles_local >=0),
CHECK (Goles_visitante >=0)
);


CREATE OR REPLACE FUNCTION torneo.jugadores()
RETURNS TRIGGER AS $$
BEGIN
    IF (
        SELECT COUNT(*)
        FROM jugadores
        WHERE id_equipo = NEW.id_equipo
    ) >= 12 THEN
        RAISE EXCEPTION 'El equipo ya tiene 12 jugadores';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER revisar_jugadores
BEFORE INSERT ON torneo.jugadores
FOR EACH ROW
EXECUTE FUNCTION torneo.jugadores();

ALTER TABLE torneo.equipos
ALTER COLUMN Capitan_documento DROP NOT NULL;




